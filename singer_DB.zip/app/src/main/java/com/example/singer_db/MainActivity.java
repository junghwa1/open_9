package com.example.singer_db;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends Activity {
    EditText edtName, edtNumber, edtNameResult, edtNumberResult;
    Button btnInit, btnInsert, btnSelect, btnUpdate, btnDelete;
    SQLiteDatabase sqlDB;
    myDBHelper myHelper;
    int Seq;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("가수 그룹 관리 DB");
        edtName = findViewById(R.id.edtName);
        edtNumber = findViewById(R.id.edtNumber);
        edtNameResult = findViewById(R.id.edtNameResult);
        edtNumberResult = findViewById(R.id.edtNumberResult);
        btnInit = findViewById(R.id.btnInit);
        btnInsert = findViewById(R.id.btnInsert);
        btnSelect = findViewById(R.id.btnSelect);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        myHelper = new myDBHelper(this);
        // 시작할때 먼저 조회
        sqlDB = myHelper.getReadableDatabase();
        Cursor cursor;
        cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null);
        String strNames = "그룹이름" + "\r\n" + "--------" + "\r\n";
        String strNumbers = "인원" + "\r\n" + "--------" + "\r\n";
        while (cursor.moveToNext()) {
            strNames += cursor.getString(0) + "\r\n";
            strNumbers += cursor.getString(1) + "\r\n";
        }
        edtNameResult.setText(strNames);
        edtNumberResult.setText(strNumbers);
        cursor.close();
        sqlDB.close();
        btnInit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sqlDB = myHelper.getWritableDatabase();
                myHelper.onUpgrade(sqlDB, 1, 2); // 인수는 아무거나 입력하면 됨.
                sqlDB.close();
                // 초기화 결과
                Toast.makeText(getApplicationContext(), "초기화됨",
                        Toast.LENGTH_SHORT).show();
            }
        });
        btnInsert.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 키보드 닫기
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(edtNumber.getWindowToken(), 0);
                try {
                    sqlDB = myHelper.getWritableDatabase();
                    sqlDB.execSQL("INSERT INTO groupTBL VALUES ( '"
                            + edtName.getText().toString().trim() + "' , "
                            + edtNumber.getText().toString().trim() + ");");
                    sqlDB.close();
                    // 입력결과 확인
                    Toast.makeText(
                            getApplicationContext(),
                            "그룹이름 : '" + edtName.getText().toString().trim()
                                    + "' 입력됨", Toast.LENGTH_SHORT).show();
                    sqlDB = myHelper.getReadableDatabase();
                    Cursor cursor;
                    cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null);
                    String strNames = "그룹이름" + "\r\n" + "--------" + "\r\n";
                    String strNumbers = "인원" + "\r\n" + "--------" + "\r\n";
                    while (cursor.moveToNext()) {
                        strNames += cursor.getString(0) + "\r\n";
                        strNumbers += cursor.getString(1) + "\r\n";
                    }
                    edtNameResult.setText(strNames);
                    edtNumberResult.setText(strNumbers);
                    cursor.close();
                    sqlDB.close();
                    // 입력결과 조회
                    Toast.makeText(getApplicationContext(), "입력결과 조회됨",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    // 입력결과 확인
                    Toast.makeText(getApplicationContext(),
                                    "SQL오류 :" + e.toString(), Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });
        btnSelect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 키보드 닫기
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(edtName.getWindowToken(), 0);
                sqlDB = myHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null);
                String strNames = "그룹이름" + "\r\n" + "--------" + "\r\n";
                String strNumbers = "인원" + "\r\n" + "--------" + "\r\n";
                while (cursor.moveToNext()) {
                    strNames += cursor.getString(0) + "\r\n";
                    strNumbers += cursor.getString(1) + "\r\n";
                }
                edtNameResult.setText(strNames);
                edtNumberResult.setText(strNumbers);
                cursor.close();
                sqlDB.close();
                // 처리결과 확인
                Toast.makeText(getApplicationContext(), "조회됨",
                        Toast.LENGTH_SHORT).show();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 키보드 닫기
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(edtNumber.getWindowToken(), 0);
                try {
                    sqlDB = myHelper.getWritableDatabase();
                    sqlDB.execSQL("UPDATE groupTBL set gNumber = "
                            + edtNumber.getText().toString().trim()
                            + " where gName = '"
                            + edtName.getText().toString().trim() + "';");
                    sqlDB.close();
                    // 처리결과 확인
                    Toast.makeText(
                            getApplicationContext(),
                            "그룹이름 : '" + edtName.getText().toString().trim()
                                    + "' 수정됨", Toast.LENGTH_SHORT).show();

                    sqlDB = myHelper.getReadableDatabase();
                    Cursor cursor;
                    cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null);
                    String strNames = "그룹이름" + "\r\n" + "--------" + "\r\n";
                    String strNumbers = "인원" + "\r\n" + "--------" + "\r\n";
                    while (cursor.moveToNext()) {
                        strNames += cursor.getString(0) + "\r\n";
                        strNumbers += cursor.getString(1) + "\r\n";
                    }
                    edtNameResult.setText(strNames);
                    edtNumberResult.setText(strNumbers);
                    cursor.close();
                    sqlDB.close();
                    // 입력결과 조회
                    Toast.makeText(getApplicationContext(), "수정결과 조회됨",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    // 입력결과 확인
                    Toast.makeText(getApplicationContext(),
                                    "SQL오류 :" + e.toString(), Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // 키보드 닫기
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                im.hideSoftInputFromWindow(edtNumber.getWindowToken(), 0);
                try {
                    sqlDB = myHelper.getWritableDatabase();
                    sqlDB.execSQL("DELETE from groupTBL where gName = '"
                            + edtName.getText().toString().trim() + "';");
                    sqlDB.close();
                    // 처리결과 확인
                    Toast.makeText(
                            getApplicationContext(),
                            "그룹이름 : '" + edtName.getText().toString().trim()
                                    + "' 삭제됨", Toast.LENGTH_SHORT).show();

                    sqlDB = myHelper.getReadableDatabase();
                    Cursor cursor;
                    cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null);
                    String strNames = "그룹이름" + "\r\n" + "--------" + "\r\n";
                    String strNumbers = "인원" + "\r\n" + "--------" + "\r\n";
                    while (cursor.moveToNext()) {
                        strNames += cursor.getString(0) + "\r\n";
                        strNumbers += cursor.getString(1) + "\r\n";
                    }
                    edtNameResult.setText(strNames);
                    edtNumberResult.setText(strNumbers);
                    cursor.close();
                    sqlDB.close();
                    // 입력결과 조회
                    Toast.makeText(getApplicationContext(), "삭제결과 조회됨",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    // 입력결과 확인
                    Toast.makeText(getApplicationContext(),
                                    "SQL오류 :" + e.toString(), Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });
    }
    public class myDBHelper extends SQLiteOpenHelper {
        public myDBHelper(Context context) {
            super(context, "groupDB", null, 1);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE  groupTBL (gName CHAR(20) PRIMARY KEY, gNumber INTEGER);");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS groupTBL");
            onCreate(db);
        }
    }
}